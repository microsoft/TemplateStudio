using System;

using MarkdownViewer.Helpers;
using Windows.UI.Xaml;

namespace MarkdownViewer.ViewModels
{
    public class MainViewModel : Observable
    {
        public MainViewModel()
        {
        }

        
    }
}
